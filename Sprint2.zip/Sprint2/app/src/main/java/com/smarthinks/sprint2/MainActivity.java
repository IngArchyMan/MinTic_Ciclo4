package com.smarthinks.sprint2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    protected EditText mUserText;
    private CardView mBtnIngresar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUserText = findViewById(R.id.editUsuario);
        mBtnIngresar = findViewById(R.id.btnIngresar);


        mBtnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validacionDeUsuario();
            }
        });

    }

    private void validacionDeUsuario() {

        final String mUserStr = mUserText.getText().toString();
        mUserText.setError(null);

        if(mUserStr.trim().isEmpty()){
            Toast.makeText(this, "El campo de usuario no puede ser vacio", Toast.LENGTH_SHORT).show();
            mUserText.setError("Este campo no puede ver vacio");
            mUserText.requestFocus();
        }


    }
}