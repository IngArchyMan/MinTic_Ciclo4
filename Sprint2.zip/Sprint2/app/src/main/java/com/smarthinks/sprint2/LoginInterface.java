package com.smarthinks.sprint2;

public interface LoginInterface {

    interface View{

    }

    interface controlador{

    }

    interface modelo{

    }
}
